import type {SeoMeta} from "../types/seo.ts";
import type {SEOProps} from "../components/SEO";

export const fetchSEO = async (page:string, query?: Record<string, string>): Promise<SEOProps> => {
    let API_BASE_URL = `https://api.clncambodia.com/api/v1/docs/seo/${page}`
    if(query && Object.keys(query).length > 0){
        const params = new URLSearchParams(query);
        API_BASE_URL += `?${params}`;
    }
    
    try {
        const res = await fetch(API_BASE_URL, {
            method: "GET",
            headers: {
                "accept": "application/json",
                "content-type": "application/json",
            }
        });
        
        if(!res.ok) {
            throw new Error(`Failed to fetch SEO data for page ${page}: ${res.status} ${res.statusText}`)
        }
        
        const data: SeoMeta = await res.json();
        
        // Map the API response to SEOProps
        // Handle empty strings and ensure we have valid values
        const baseUrl = `https://clncambodia.com/${page === 'home' ? '' : page === 'contact-us' ? 'contact-us' : page}`;
        
        return {
            title: data.title || undefined,
            description: data.description || undefined,
            keywords: data.keywords || undefined,
            image: data.image || undefined,
            ogTitle: data.ogTitle || data.title || undefined,
            ogDescription: data.ogDescription || data.description || undefined,
            ogImage: data.ogImage || data.image || undefined,
            url: data.url || data.canonical || baseUrl,
        };
    } catch (error) {
        console.error(`Error fetching SEO for page ${page}:`, error);
        throw error;
    }
}