import React, { useState, useEffect } from 'react';
import type { QuoteRequest } from '../types/quote.types';
import type { Location } from '../types/common.types';
import type { TransportMode } from '../types/quote.types';
import { useQuotes } from '../hooks/useQuotes';
import { validateQuoteRequest } from '../utils/validators';
import { MODE_STYLES, SERVICE_STYLES, CLEARANCE_OPTIONS, CONTAINER_TYPE_OPTIONS, WEIGHT_BREAK_OPTIONS, CONTAINER_WEIGHT_LIMITS, AIR_WEIGHT_LIMITS, getWeightBreakFromWeight } from '../utils/constants';
import { showError } from '../../../utils/swalHelper';
import LocationSearch from './LocationSearch';
import CommoditySearch from './CommoditySearch';
import QuoteResultTicket from './QuoteResultTicket';

type Mode = keyof typeof MODE_STYLES; // 'sea' | 'air' | 'road'
type Service = keyof typeof SERVICE_STYLES;
type Clearance = 'import' | 'export';

// Common air-freight packaging unit types.


// Per-mode cargo section shape. Sea and Road share the same fields
// (clearance → container type, commodity, weight, quantity). Air swaps
// container type for a packaging unit and drops quantity entirely.
const CARGO_FIELD_OPTIONS: Record<Mode, {
  showContainerType: boolean;
  showPackagingUnit: boolean;
  showQuantity: boolean;
  showWeightBreak: boolean;
}> = {
  sea:  { showContainerType: true,  showPackagingUnit: false, showQuantity: true,  showWeightBreak: false },
  road: { showContainerType: true,  showPackagingUnit: false, showQuantity: true,  showWeightBreak: false },
  air:  { showContainerType: false, showPackagingUnit: true,  showQuantity: false, showWeightBreak: true  },
};

// ── Field label ──────────────────────────────────────────────────────
const FieldLabel = ({ children, required }: { children: React.ReactNode; required?: boolean }) => (
  <label className="block text-sm font-semibold text-slate-600 mb-2">
    {children}{required && <span className="text-red-500 ml-1">*</span>}
  </label>
);

const FieldError = ({ msg }: { msg?: string }) =>
  msg ? <p className="mt-1.5 text-xs text-red-500">{msg}</p> : null;

// ── Pill option button (used for cargo-detail choices) ───────────────
const OptionPill = <T extends string>({
  options,
  value,
  onChange,
  accent,
}: {
  options: readonly T[];
  value: string;
  onChange: (v: T) => void;
  accent: string;
}) => (
  <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto overflow-x-hidden pr-1">
    {options.map(opt => {
      const selected = value === opt;
      return (
        <button
          key={opt}
          type="button"
          onClick={() => onChange(opt)}
          className="px-4 h-16 rounded-xl border text-sm font-semibold transition-all duration-200"
          style={{
            borderColor: selected ? accent : '#cbd5e1',
            background:  selected ? accent : '#ffffff',
            color:       selected ? '#ffffff' : '#475569',
          }}
        >
          {opt}
        </button>
      );
    })}
  </div>
);

// ── Section wrapper ──────────────────────────────────────────────────
const Section = ({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) => (
  <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6">
    <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-5">{title}</h2>
    {children}
  </div>
);

// ── Transport mode selector card ─────────────────────────────────────
const ModeCard = ({
  modeKey,
  selected,
  onSelect,
}: {
  modeKey: Mode;
  selected: boolean;
  onSelect: () => void;
}) => {
  const style = MODE_STYLES[modeKey];
  return (
    <button
      type="button"
      onClick={onSelect}
      className="h-[130px] rounded-2xl border-2 px-5 flex flex-col items-start justify-center gap-1 text-left transition-all duration-300 hover:shadow-md"
      style={{
        borderColor: selected ? style.border : '#e2e8f0',
        background:  selected ? style.bg : '#ffffff',
      }}
    >
      <span className="text-2xl">{style.icon}</span>
      <span className="font-bold text-base" style={{ color: selected ? style.primary : '#0f172a' }}>
        {style.label}
      </span>
      <span className="text-xs text-slate-500">{style.tagline}</span>
    </button>
  );
};

// ── Service level selector card ──────────────────────────────────────
const ServiceCard = ({
  serviceKey,
  selected,
  onSelect,
}: {
  serviceKey: Service;
  selected: boolean;
  onSelect: () => void;
}) => {
  const style = SERVICE_STYLES[serviceKey];
  return (
    <button
      type="button"
      onClick={onSelect}
      className="h-[130px] rounded-2xl border-2 px-5 flex flex-col items-start justify-center gap-1 text-left transition-all duration-300 hover:shadow-md"
      style={{
        borderColor: selected ? style.border : '#e2e8f0',
        background:  selected ? style.bg : '#ffffff',
      }}
    >
      <span className="text-2xl">{style.icon}</span>
      <span className="font-bold text-base" style={{ color: selected ? style.primary : '#0f172a' }}>
        {style.label}
      </span>
      <span className="text-xs text-slate-500">{style.tagline}</span>
    </button>
  );
};

const inputCls = "w-full h-16 px-4 rounded-xl border border-slate-300 text-base text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-slate-300 transition-all";

const QuoteForm: React.FC = () => {
  const [mode, setMode] = useState<Mode>('sea');
  // NOTE: pick whatever the real default key in SERVICE_STYLES is (e.g. 'standard').
  const [service, setService] = useState<Service>(Object.keys(SERVICE_STYLES)[0] as Service);
  const [clearance, setClearance] = useState<Clearance>('import');
  const [formData, setFormData] = useState<QuoteRequest>({
    origin:             '',
    destination:        '',
    clearance:          'import',
    containerSize:      '',
    containerQuantity:  1,
    containerMaxWeight: 0,
    weightBreak:        '',
    soc:                false,
    equipmentType:      '',
    commodity:          '',
    vesselDeparture:    '',
    country:            '',
    mode:               'sea',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const { quoteResult, getQuote, resetQuote, loading, error } = useQuotes();
  // Commodity is the parent for Import/Export clearance & trucking pricing on
  // the backend, so the customer must pick from the same canonical list the
  // admin prices against — a free-text field would never match.

  const activeStyle = MODE_STYLES[mode];
  const cargoConfig = CARGO_FIELD_OPTIONS[mode];

  const weightLimits =
  mode === 'air'
    ? AIR_WEIGHT_LIMITS
    : formData.containerSize
      ? CONTAINER_WEIGHT_LIMITS[formData.containerSize as keyof typeof CONTAINER_WEIGHT_LIMITS]
      : undefined;

  useEffect(() => {
    if (error) {
      // The backend returns a terse "No available rates" when it can't find
      // a matching rate card. That's technically correct but not actionable
      // — surface the actual fields worth double-checking instead.
      const isNoRatesError = /no available rates/i.test(error);
      showError(
        isNoRatesError ? 'No Rates Available' : 'Unable to get quote',
        isNoRatesError
          ? 'No available rates were found for this request. Please double-check the Departure Date, Mode, Commodity, Services, Clearance, Container Type, or Weight Bracket (Kg)*, then try again.'
          : error
      );
    }
  }, [error]);
  
  // ── Handlers ──────────────────────────────────────────────────────
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    const nextValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;

    setFormData(prev => {
      const next = { ...prev, [name]: nextValue };

      // Gross weight drives the weight bracket automatically in Air mode, so
      // the two fields can never disagree with each other or with the
      // backend's pricing table. Out-of-range weights clear the bracket
      // rather than guessing wrong — validateQuoteRequest surfaces the
      // range error via AIR_WEIGHT_LIMITS on submit.
      if (name === 'containerMaxWeight' && mode === 'air') {
        const weightKg = Number(value) || 0;
        next.weightBreak = getWeightBreakFromWeight(weightKg) ?? '';
      }

      return next;
    });

    if (errors[name]) setErrors(prev => { const n = { ...prev }; delete n[name]; return n; });
    if (name === 'containerMaxWeight' && errors.weightBreak) {
      setErrors(prev => { const n = { ...prev }; delete n.weightBreak; return n; });
    }
  };

  const handleCommodityChange = (value: string) => {
    setFormData(prev => ({ ...prev, commodity: value }));
    if (errors.commodity) setErrors(prev => { const n = { ...prev }; delete n.commodity; return n; });
  };

  const handleLocationChange = (field: 'origin' | 'destination', location: Location) => {
    setFormData(prev => ({
      ...prev,
      [field]:  location.name,
      country: field === 'destination' ? location.country : prev.country,
    }));
    if (errors[field]) setErrors(prev => { const n = { ...prev }; delete n[field]; return n; });
  };

  const handleModeChange = (next: Mode) => {
    setMode(next);
    setFormData(prev => ({
      ...prev,
      mode: next as TransportMode,
      equipmentType: '',
      containerSize: '',
      weightBreak: '',
      containerQuantity: next === 'air' ? 0 : prev.containerQuantity,
    }));
  };

  const handleClearanceChange = (next: Clearance) => {
    setClearance(next);
    // Container type / weight bracket options depend on clearance (export has
    // more container options than import), so drop any selection that may no
    // longer be valid. Also push clearance onto formData — rate lookup and
    // pricing are keyed by clearance direction (export/import), so it must
    // reach the backend.
    setFormData(prev => ({ ...prev, clearance: next, containerSize: '', weightBreak: '' }));
  };

  const handleServiceChange = (next: Service) => {
    setService(next);
    // If service level ever needs to travel with the request payload, set it
    // on formData here too (once QuoteRequest has a matching field), e.g.:
    // setFormData(prev => ({ ...prev, serviceLevel: next }));
  };

  const handleQuantityChange = (delta: number) => {
    setFormData(prev => ({
      ...prev,
      containerQuantity: Math.max(1, prev.containerQuantity + delta),
    }));
  };

  const getMinDate = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  // ── Validation ────────────────────────────────────────────────────
  const validateAll = (): boolean => {
    const errs: Record<string, string> = {};
    if (!formData.origin)          errs.origin          = 'Origin is required.';
    if (!formData.destination)     errs.destination     = 'Destination is required.';
    if (!formData.vesselDeparture) errs.vesselDeparture  = 'Departure date is required.';
  
    const vErrs = validateQuoteRequest(formData);
    vErrs.forEach(err => {
      if (!errs[err.field]) errs[err.field] = err.message;
    });
    if (vErrs.length > 0) errs.general = vErrs[0].message;
  
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  // ── Submit ────────────────────────────────────────────────────────
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateAll()) return;
    await getQuote(formData);
  };

  const handleReset = () => {
    resetQuote();
    setErrors({});
    setMode('sea');
    setService(Object.keys(SERVICE_STYLES)[0] as Service);
    setClearance('import');
    setFormData({
      origin: '', destination: '', clearance: 'import', containerSize: '', containerQuantity: 1,
      containerMaxWeight: 0, weightBreak: '', soc: false, equipmentType: '', commodity: '',
      vesselDeparture: '', country: '', mode: 'sea',
    });
  };

  // ── Result view ───────────────────────────────────────────────────
  if (quoteResult) {
    const cargoLabel =
      mode === 'air'
        ? (formData.weightBreak || undefined)
        : formData.containerSize
        ? `${formData.containerQuantity} × ${formData.containerSize}`
        : undefined;

    return (
      <div className="max-w-[1000px] mx-auto bg-white rounded-3xl border border-slate-200 shadow-sm p-6 md:p-10">
        <QuoteResultTicket
          quoteResult={quoteResult}
          origin={formData.origin || quoteResult.origin}
          destination={formData.destination || quoteResult.destination}
          commodity={formData.commodity || quoteResult.commodity || ''}
          mode={mode}
          clearance={clearance}
          cargoLabel={cargoLabel}
          departureDate={formData.vesselDeparture}
          onReset={handleReset}
        />
      </div>
    );
  }

  // ── Form ──────────────────────────────────────────────────────────
  return (
    <div className="max-w-[1000px] mx-auto bg-white rounded-3xl border border-slate-200 shadow-sm p-6 md:p-10">

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl md:text-5xl font-bold tracking-tight text-slate-900">
          Request an Instant Shipping Quote
        </h1>
        <p className="text-slate-500 text-lg mt-3">
          Calculate rates instantly with our upgraded logistics engine
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">

        {errors.general && (
          <div className="flex gap-2 p-4 rounded-xl bg-red-50 border border-red-200">
            <svg viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth={2} className="w-4 h-4 flex-shrink-0 mt-0.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-sm text-red-600">{errors.general}</p>
          </div>
        )}

        {/* SECTION 1 — Route Details */}
        <Section title="Route Details">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <FieldLabel required>Origin</FieldLabel>
              <LocationSearch
                label=""
                value={formData.origin}
                onChange={l => handleLocationChange('origin', l)}
                placeholder="e.g. Phnom Penh"
                required
              />
              <FieldError msg={errors.origin} />
            </div>

            <div>
              <FieldLabel required>Destination Location</FieldLabel>
              <LocationSearch
                label=""
                value={formData.destination}
                onChange={l => handleLocationChange('destination', l)}
                placeholder="e.g. Shanghai"
                required
              />
              <FieldError msg={errors.destination} />
            </div>

            <div className="md:col-span-2">
              <FieldLabel required>Departure Date</FieldLabel>
              <input
                type="date"
                name="vesselDeparture"
                value={formData.vesselDeparture}
                min={getMinDate()}
                onChange={handleInputChange}
                className={inputCls}
              />
              <FieldError msg={errors.vesselDeparture} />
            </div>
          </div>
        </Section>

        {/* SECTION 2 — Transport Mode */}
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-3 px-1">Transport Mode</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {(Object.keys(MODE_STYLES) as Mode[]).map(key => (
              <ModeCard
                key={key}
                modeKey={key}
                selected={mode === key}
                onSelect={() => handleModeChange(key)}
              />
            ))}
          </div>
        </div>

        {/* SECTION 3 — Service Level */}
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-3 px-1">Services</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {(Object.keys(SERVICE_STYLES) as Service[]).map(key => (
              <ServiceCard
                key={key}
                serviceKey={key}
                selected={service === key}
                onSelect={() => handleServiceChange(key)}
              />
            ))}
          </div>
        </div>

        {/* SECTION 4 — Cargo Details */}
        <Section title="Cargo Details">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <FieldLabel required>Clearance</FieldLabel>
              <div className="flex flex-wrap gap-2">
                {CLEARANCE_OPTIONS.map(opt => {
                  const selected = clearance === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => handleClearanceChange(opt.value)}
                      className="px-4 h-16 rounded-xl border text-sm font-semibold transition-all duration-200"
                      style={{
                        borderColor: selected ? activeStyle.primary : '#cbd5e1',
                        background:  selected ? activeStyle.primary : '#ffffff',
                        color:       selected ? '#ffffff' : '#475569',
                      }}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {cargoConfig.showContainerType && (
              <div>
                <FieldLabel required>Container Type</FieldLabel>
                <OptionPill
                  options={CONTAINER_TYPE_OPTIONS[clearance]}
                  value={formData.containerSize}
                  onChange={v => {
                    setFormData(p => ({ ...p, containerSize: v }));
                    if (errors.containerMaxWeight) setErrors(prev => { const n = { ...prev }; delete n.containerMaxWeight; return n; });
                  }}
                  accent={activeStyle.primary}
                />
              </div>
            )}

            {cargoConfig.showWeightBreak && (
              <div>
                <FieldLabel required>Weight Bracket (Kg)</FieldLabel>
                <OptionPill
                  options={WEIGHT_BREAK_OPTIONS}
                  value={formData.weightBreak ?? ''}
                  onChange={v => setFormData(p => ({ ...p, weightBreak: v }))}
                  accent={activeStyle.primary}
                />
                <p className="mt-1.5 text-xs text-slate-400">
                  Auto-selected from Gross Weight — adjust the weight below or tap a bracket to override.
                </p>
                <FieldError msg={errors.weightBreak} />
              </div>
            )}


            <div>
              <FieldLabel required>Commodity</FieldLabel>
              <CommoditySearch 
                label=''
                value={formData.commodity}
                onChange={handleCommodityChange}
                required
              />
              <FieldError msg={errors.commodity} />
            </div>

            <div>
                <FieldLabel required>Gross Weight (kg)</FieldLabel>
                <input
                  type="number"
                  name="containerMaxWeight"
                  value={formData.containerMaxWeight || ''}
                  onChange={handleInputChange}
                  placeholder={weightLimits ? `${weightLimits.min.toLocaleString()} – ${weightLimits.max.toLocaleString()}` : 'e.g. 50000'}
                  min={weightLimits?.min ?? 0}
                  max={weightLimits?.max}
                  className={inputCls}
                />
                {weightLimits && (
                  <p className="mt-1.5 text-xs text-slate-400">
                    Allowed range for {mode === 'air' ? 'Air freight' : formData.containerSize}:{' '}
                    {weightLimits.min.toLocaleString()}kg – {weightLimits.max.toLocaleString()}kg
                  </p>
                )}
                <FieldError msg={errors.containerMaxWeight} />
              </div>

            {cargoConfig.showQuantity && (
              <div>
                <FieldLabel required>Container Quantity</FieldLabel>
                <div className="w-full flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => handleQuantityChange(-1)}
                    className="w-[20%] h-16 rounded-xl border border-slate-300 flex items-center justify-center font-bold text-xl transition-colors hover:bg-slate-100 text-slate-600"
                  >
                    −
                  </button>
                  <span className="w-12 text-center text-lg font-semibold text-slate-900">
                    {formData.containerQuantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleQuantityChange(1)}
                    className="w-[20%] h-16 rounded-xl border border-slate-300 flex items-center justify-center font-bold text-xl transition-colors hover:bg-slate-100 text-slate-600"
                  >
                    +
                  </button>
                </div>
              </div>
            )}
          </div>
        </Section>

        {/* BOTTOM CTA */}
        <button
          type="submit"
          disabled={loading}
          className="w-full h-[50px] rounded-2xl text-xl font-semibold text-white transition-all duration-300 hover:scale-[1.01] hover:shadow-lg disabled:opacity-60 disabled:hover:scale-100 flex items-center justify-center gap-2"
          style={{ background: activeStyle.primary }}
        >
          {loading ? (
            <>
              <span className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
              Calculating…
            </>
          ) : (
            <>Calculate Quote Instantly →</>
          )}
        </button>
      </form>
    </div>
  );
};

export default QuoteForm;